from pathlib import Path
import subprocess, json, hashlib, argparse, os, re, importlib.util

parser=argparse.ArgumentParser()
parser.add_argument('--source',required=True)
parser.add_argument('--out',required=True)
parser.add_argument('--base',required=True)
parser.add_argument('--templates',required=True)
parser.add_argument('--daily-repository',required=True)
parser.add_argument('--stress-repository',required=True)
parser.add_argument('--stress-transformer',required=True)
parser.add_argument('--fit-helper',required=True)
parser.add_argument('--previous-private',required=True)
args=parser.parse_args()
root=Path(args.out);templates=Path(args.templates);base=args.base
donor='35dab989f0a6a6cb76ce4e1eabe4567c02de6ace'
stress_donor='0b0f65c17e3e9802a24814d29d4d5cabb7bd6d23'
transformer_sha='753478a68fb28b8355a68930599486d63ca25fcca55032f3746f2beedb886254'
original_transformer_sha='a697a2cfde2a89fe791bb8db5f2cc4142a511c7776dd768b378b135b25a699bd'
top_transformer_sha='bd4358a63cda35f57d42e42963b9a1b81ba7c0f90ef19aac489d28cbb5a1d6f8'
g2_chain_sha='605357700fccafa35001663b571eea06f5e53f7eae69e916e7aafed7aecdd806'
daily_config_transformer_sha='8a6e30b3a0488404b92fc426052ac9aa9af16480b8973d5617e2267fcd143f73'
original_base='19400eb773aa39cc3caddbda752b9cd80309943e'
ledger='release/approved-runtime-composition.json'
key='codingCompletion20261016'
scope='release/coding-completion-scope-20261016.mjs'
test='tests/coding-completion-scope-20261016.test.mjs'
seo='release/seo-audit-scope-20261016.mjs'
seo_test='tests/seo-audit-scope-20261016.test.mjs'
comp='release/approved-runtime-composition.mjs'
csv_test='member-experience/tests/weight-import-mapping-ui.test.mjs'
wrapper='scheduled-knowledge-v1.js'
daily_paths=['.github/workflows/daily-website-content-preflight.yml','daily-content/README.md','daily-content/engine.mjs','daily-content/engine.test.mjs',wrapper,'wrangler.jsonc']
maintenance=sorted([scope,test,seo,seo_test,comp,wrapper,csv_test])
if root.exists():raise SystemExit('STOP: output exists; preserve prior private source and use a new isolated output')
subprocess.run(['/usr/bin/git','clone','--dissociate','--no-hardlinks','--no-checkout',args.source,str(root)],check=True,capture_output=True)
def git(*a,input=None):
 return subprocess.check_output(['/usr/bin/git','-C',str(root),*a],input=input)
def text(ref,p):return git('show',ref+':'+p).decode()
def blob(ref,p):return git('rev-parse',ref+':'+p).decode().strip()
def write(p,value):
 path=root/p;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(value)
def commit(tree,parent,message):
 parents=[parent] if isinstance(parent,str) else parent
 parent_args=[part for p in parents for part in ['-p',p]]
 return git('-c','user.name=Codex','-c','user.email=codex@localhost','commit-tree',tree,*parent_args,input=(message+'\n').encode()).decode().strip()
for source,ref in [(args.daily_repository,donor),(args.stress_repository,stress_donor),(args.daily_repository,args.previous_private),('https://github.com/shiftsometimber/shift-core.git',base)]:
 if subprocess.run(['/usr/bin/git','-C',str(root),'cat-file','-e',ref+'^{commit}'],capture_output=True).returncode:
  git('fetch','--no-tags',source,ref)
git('checkout','--detach','--force',base)
assert git('status','--porcelain').strip()==b''
# Keep every existing immutable-kernel guard. Materialise a genuine independent
# object store so supported native immutable-fact reuse can apply without a new
# aggregate-lifetime fact map or any relaxed borrowing/configuration predicate.
def assert_independent_object_store():
 assert (root/'.git').is_dir() and not (root/'.git').is_symlink(),'ordinary native .git directory required'
 for suffix in ['objects/info/alternates','objects/info/http-alternates']:
  assert not (root/'.git'/suffix).exists(),('genuine object dissociation required',suffix)
 for suffix in ['commondir','gitdir']:
  assert not (root/'.git'/suffix).exists(),('independent native source required',suffix)
assert_independent_object_store()
# Full local object copying also preserves the already-recovered unreferenced
# native fixture authority. A history-only/shallow source is insufficient.
native_fixture_trees={
 'fd2782d745295ee9fd80a28ed7eae642aedc566d':'4663a5fd968343c29e70322d148e7dc8d598f094',
 'f3acbfdc2f0fbe8c14d5940dee9136377f257cc8':'f5e4d55cba045b4017bdaa7991f74c80227f0f9d',
 '5e2a6bbe7714fe098eebfa22bc7acbe9e3d2d5c2':'fadd610c5cf52dc62a2202f5db2abae50d05b9d5'
}
for fixture,tree in native_fixture_trees.items():
 assert git('rev-parse',fixture+'^{tree}').decode().strip()==tree,('Preserve exact recovered native fixture objects before graph construction',fixture)
assert not [p for p in git('ls-tree','-r','--name-only',base).decode().splitlines() if p.split('/')[-1]=='AGENTS.md'],'Read source AGENTS instructions first'
base_prior=json.loads(text(base,ledger))
use_gp_top='gpMemberCode20261014' in base_prior
selected_top=None
def load_pinned(name,filename,expected):
 path=templates/filename
 assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,('Exact preparation helper changed',filename)
 spec=importlib.util.spec_from_file_location(name,str(path));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
if use_gp_top:
 top_adapter=load_pinned('owned_gp_coding_top','current_runtime_coding_top_adapter.py',top_transformer_sha)
 selected_top=top_adapter.select_top(base_prior)
 top_path=selected_top['path'];maintenance.remove(seo);maintenance.append(top_path);maintenance.sort()
else:top_path=seo
csv_uses_admitted_week='myTimberRecordedWeekActivation20261014' in base_prior
if csv_uses_admitted_week:
 csv_source=text(base,csv_test)
 if 'currentRuntimePreservation20261016' in base_prior:
  assert csv_source.count('const current=currentRuntimePreservationHistoricalView();')==1,'Retain exact current runtime CSV factory'
  assert csv_source.count("retained.base,current.head,'--','my-timber-app','wrangler.jsonc','wrangler.coaching.jsonc','shift-coach/worker.mjs'")==1,'Retain whole original current CSV query'
  assert csv_source.count("assert.equal(diff,'');")==1 and csv_source.count('current.assertCurrent();')==1,'Retain original empty diff and current source check'
 else:
  assert csv_source.count("retained.base,recordedWeekActivationHistoricalView().head,'--','my-timber-app'")==1,'Keep exact admitted W CSV comparison; reconcile a changed guard rather than overwrite it'
 maintenance.remove(csv_test)
for p in [wrapper]:assert blob(base,p)==blob(original_base,p),(p,'actual base differs; reconcile instead of overwriting')
for p in daily_paths[:4]:assert subprocess.run(['/usr/bin/git','-C',str(root),'cat-file','-e',base+':'+p],capture_output=True).returncode!=0,(p,'new path already exists')
assert hashlib.sha256(Path(args.stress_transformer).read_bytes()).hexdigest()==transformer_sha,'Actual approved transformer changed'
spec=importlib.util.spec_from_file_location('owned_stress_fit_g2_transformer',args.stress_transformer)
transformer=importlib.util.module_from_spec(spec);spec.loader.exec_module(transformer)
def optional(ref,p):
 if subprocess.run(['/usr/bin/git','-C',str(root),'cat-file','-e',ref+':'+p],capture_output=True).returncode:return None
 return text(ref,p)
# Daily-only delivery preserves actual current G2, movement and stress bytes.
files={p:text(donor,p) for p in daily_paths}
config_transformer=templates/'daily-config-transformer.py'
assert hashlib.sha256(config_transformer.read_bytes()).hexdigest()==daily_config_transformer_sha,'Exact three-var current-source transformer changed'
config_spec=importlib.util.spec_from_file_location('owned_daily_config_transformer',str(config_transformer));daily_config=importlib.util.module_from_spec(config_spec);config_spec.loader.exec_module(daily_config)
daily_configuration=daily_config.prepare_daily_configuration(text(base,'wrangler.jsonc'),text(original_base,'wrangler.jsonc'),files['wrangler.jsonc'])
files['wrangler.jsonc']=daily_configuration['content']
paths=sorted(files)
assert len(paths)==6
payload_blobs={p:git('hash-object','--stdin',input=value.encode()).decode().strip() for p,value in files.items()}
for p in paths:
 write(p,files[p])
 assert git('hash-object',str(root/p)).decode().strip()==payload_blobs[p]
git('add','--',*paths)
assert set(git('diff','--cached','--name-only',base).decode().splitlines())==set(paths)
payload_tree=git('write-tree').decode().strip()
payload=commit(payload_tree,[base,donor,args.previous_private],'Reconcile exact authorised six-path private daily content payload with actual current Core source; no production acceptance')
git('checkout','--detach','--force',payload)

sources={p:text(base,p) for p in [top_path,seo_test,comp]+([] if csv_uses_admitted_week else [csv_test])}
sources[wrapper]=text(payload,wrapper)
original={p:text(base,p) for p in sources}
inverses={p:[] for p in sources}
# Runtime payload inverses preserve the actual new Core worker, G2 entry and
# previous Fit source. They are not additional maintenance changes.
# No unrelated runtime payload inverses: those files remain byte-exact.
wrangler_before=text(base,'wrangler.jsonc');wrangler_after=files['wrangler.jsonc']
wrangler_additions='    "DAILY_WEBSITE_CONTENT_ENABLED": "true",\n    "DAILY_CONTENT_GATEWAY": "shift-ai",\n    "DAILY_CONTENT_BUDGET_VERIFIED": "true",\n'
assert wrangler_after.count(wrangler_additions)==1 and wrangler_after.replace(wrangler_additions,'')==wrangler_before
inverses['wrangler.jsonc']=[['  "vars": {\n','  "vars": {\n'+wrangler_additions]]
if not use_gp_top:
 # Old immutable policy contains quoted prior source fragments. Never edit those
 # historical strings while adding the outer adapter to the actual module body.
 policy_match=re.search(r'^const policy=\{[^\n]+\};\n',sources[seo],re.M)
 assert policy_match
 seo_policy_line=policy_match.group(0)
 seo_policy_token='// EXACT_UNCHANGED_PRIOR_SEO_POLICY_BINDING\n'
 sources[seo]=sources[seo].replace(seo_policy_line,seo_policy_token,1)
def replace(p,old,new):
 assert old and sources[p].count(old)==1,(p,'exact unique source fragment required',old[:120])
 sources[p]=sources[p].replace(old,new);inverses[p].append([old,new])

# A separate maintenance transform removes only the exact donor's extra EOF newline.
donor_wrapper=sources[wrapper]
assert donor_wrapper.endswith('\n\n') and not donor_wrapper.endswith('\n\n\n')
sources[wrapper]=donor_wrapper[:-1]
# Its historical fixture inverse must restore the complete pre-daily source.
inverses[wrapper]=[[original[wrapper],sources[wrapper]]]

replace(comp,"import {SEO_AUDIT_PATHS,SEO_AUDIT_MAINTENANCE}","import {CODING_COMPLETION_PATHS,CODING_COMPLETION_MAINTENANCE} from './coding-completion-scope-20261016.mjs';\nimport {SEO_AUDIT_PATHS,SEO_AUDIT_MAINTENANCE}")
old='for(const p of [...SEO_AUDIT_PATHS,...SEO_AUDIT_MAINTENANCE])RECONCILIATION_PATHS.add(p);'
replace(comp,old,old+'\nfor(const p of [...CODING_COMPLETION_PATHS,...CODING_COMPLETION_MAINTENANCE])RECONCILIATION_PATHS.add(p);')
replace(seo_test,"import test from 'node:test';","import './coding-completion-scope-20261016.test.mjs';\nimport test from 'node:test';")

if not csv_uses_admitted_week:
 # Keep the independent CSV guard's actual current query and final assertion.
 # A separately admitted exact daily config delta may additionally prove the
 # whole prior file, then compare the original CSV base to that literal source.
 replace(csv_test,"import test from 'node:test';","import {codingCompletionHistoricalView,codingCompletionOriginalSource} from '../../release/coding-completion-scope-20261016.mjs';\nimport test from 'node:test';")
 old=" const diff=execFileSync('git',['diff','--name-only',retained.base,'HEAD','--','my-timber-app','wrangler.jsonc','wrangler.coaching.jsonc','shift-coach/worker.mjs'],{encoding:'utf8'}).trim();"
 new=""" const currentDiff=execFileSync('git',['diff','--name-only',retained.base,'HEAD','--','my-timber-app','wrangler.jsonc','wrangler.coaching.jsonc','shift-coach/worker.mjs'],{encoding:'utf8'}).trim();
  let diff=currentDiff;
  if(currentDiff==='wrangler.jsonc'){
   const admitted=codingCompletionHistoricalView();assert(admitted,'Exact separately authorised daily configuration admission required');
   const currentConfig=execFileSync('git',['show','HEAD:wrangler.jsonc'],{encoding:'utf8'}),priorConfig=execFileSync('git',['show',admitted.head+':wrangler.jsonc'],{encoding:'utf8'});
   assert.equal(codingCompletionOriginalSource('wrangler.jsonc',currentConfig,admitted),priorConfig,'Whole protected configuration must restore after only the three authorised daily vars');
   diff=execFileSync('git',['diff','--name-only',retained.base,admitted.head,'--','my-timber-app','wrangler.jsonc','wrangler.coaching.jsonc','shift-coach/worker.mjs'],{encoding:'utf8'}).trim();admitted.assertCurrent();
  }"""
 replace(csv_test,old,new)
 
if use_gp_top:
 top_result=top_adapter.transform(sources[top_path],expected_source_blob=blob(base,top_path),kind=selected_top['kind'])
 sources[top_path]=top_result['text'];inverses[top_path]=top_result['inverses']
 assert text(base,seo)==text(payload,seo),'Original admitted W/GP SEO module must remain unchanged'
else:
 replace(seo,"import assert from 'node:assert/strict';","import {codingCompletionHistoricalView,codingCompletionOriginalSource,assertCodingCompletionView} from './coding-completion-scope-20261016.mjs';\nimport assert from 'node:assert/strict';")
 old="function inverse(path,value){"
 helper="""const seoNativeFacts=Object.freeze({head,blob,content,diff,ancestor,clean});
 function seoProjectedFacts(outer){
  if(!outer)return seoNativeFacts;
  assertCodingCompletionView(outer);
  return{head:()=>{outer.assertCurrent();return outer.head},blob:outer.blob,content:outer.content,diff:outer.diff,ancestor:outer.ancestor,clean:outer.assertCurrent};
 }
 const seoNativeAuthentic=authentic;
 function inverse(path,value){"""
 replace(seo,old,helper)
 old="export function verifySeoAuditRepair(c,{rawHead=head(),read=blob,readContent=content,readDiff=diff,isAncestor=ancestor}={}){"
 has_native_batch='const nativeFacts=readSeoNativeImmutableFacts(' in sources[seo]
 has_private_expected_worker='function verifySeoAuditRepairExact(c,' in sources[seo]
 # The public verifier's native reader identity predicates stay native; supplied
 # outer aliases still execute their real callbacks at every existing call site.
 verifier_facts='head,diff,ancestor,clean' if has_native_batch else 'head,blob,content,diff,ancestor,clean'
 if has_private_expected_worker:
  worker="function verifySeoAuditRepairExact(c,{rawHead=head(),read=blob,readContent=content,readDiff=diff,isAncestor=ancestor}={},captureExpected=null){"
  replace(seo,worker,worker.replace('captureExpected=null){','captureExpected=null,outer=null){')+"\n const facts=seoProjectedFacts(outer),{"+verifier_facts+"}=facts;")
  replace(seo,old,old.replace('export function verifySeoAuditRepair(', 'function verifySeoAuditRepairOriginal(').replace('}={}){','}={},outer=null){'))
  replace(seo,"return verifySeoAuditRepairExact(c,{rawHead,read,readContent,readDiff,isAncestor});","return verifySeoAuditRepairExact(c,{rawHead,read,readContent,readDiff,isAncestor},null,outer);")
 else:
  new="function verifySeoAuditRepairOriginal(c,{rawHead=head(),read=blob,readContent=content,readDiff=diff,isAncestor=ancestor}={},outer=null){\n const facts=seoProjectedFacts(outer),{"+verifier_facts+"}=facts;"
  replace(seo,old,new)
  old="function authentic(value,r,p,h=head(),kind='read'){const ref=r==='HEAD'?h:r;if(kind==='read'&&value===blob(ref,p))return true;const actual=content(ref,p),prefix='tree '+ref+':'+p+'\\n';return value===actual||(actual.startsWith(prefix)&&value===actual.replace(prefix,'tree '+r+':'+p+'\\n'));}"
  new="function authentic(value,r,p,h=head(),kind='read',facts=seoNativeFacts){const ref=r==='HEAD'?h:r;if(kind==='read'&&value===facts.blob(ref,p))return true;const actual=facts.content(ref,p),prefix='tree '+ref+':'+p+'\\n';return value===actual||(actual.startsWith(prefix)&&value===actual.replace(prefix,'tree '+r+':'+p+'\\n'));}"
  replace(seo,old,new)
 historical_facts="function seoAuditHistoricalViewOriginal(reader=null,outer=null){\n const facts=seoProjectedFacts(outer),{head,blob,content,diff,ancestor,clean}=facts;"
 if not has_private_expected_worker:historical_facts+="const authentic=(v,r,p,h=head(),kind='read')=>seoNativeAuthentic(v,r,p,h,kind,facts);"
 replace(seo,"export function seoAuditHistoricalView(reader=null){",historical_facts)
 if has_private_expected_worker:
  old="verifySeoAuditRepairExact(c,{rawHead},facts=>{assert(!nativeExpected,'One private native facts frame required');nativeExpected=facts;});"
  new="verifySeoAuditRepairExact(c,{rawHead,read:blob,readContent:content,readDiff:diff,isAncestor:ancestor},facts=>{assert(!nativeExpected,'One private native facts frame required');nativeExpected=facts;},outer);"
  replace(seo,old,new)
 else:replace(seo,"verifySeoAuditRepair(c,{rawHead});","verifySeoAuditRepairOriginal(c,{rawHead,read:blob,readContent:content,readDiff:diff,isAncestor:ancestor},outer);")
 replace(seo,"const assertCurrent=()=>{const fresh=freshSeoSourceHead();","const assertCurrent=()=>{if(outer){outer.assertCurrent();return;}const fresh=freshSeoSourceHead();")
 batch_line=" const nativeFacts=readSeoNativeImmutableFacts({head:rawHead,base:policy.base,payload:policy.payload,maintenanceSource,paths:policy.paths,maintenancePaths:policy.maintenancePaths,inversePaths:Object.keys(policy.inverses),ledger});"
 if batch_line in sources[seo]:
  new_batch=batch_line.replace('const nativeFacts=','const capturedNativeFacts=')+"\n const nativeFacts=outer?Object.freeze({blob:(r,p)=>{outer.assertCurrent();const value=capturedNativeFacts.blob(r==='HEAD'?outer.head:r,p);outer.assertCurrent();return value},content:(r,p)=>{outer.assertCurrent();const value=capturedNativeFacts.content(r==='HEAD'?outer.head:r,p);outer.assertCurrent();return value}}):capturedNativeFacts;"
  replace(seo,batch_line,new_batch)
 replace(seo,"export function seoAuditOriginalSource(path,bytes){","function seoAuditOriginalSourceOriginal(path,bytes,outer=null){\n const {head,content}=seoProjectedFacts(outer);")
 wrappers="""
 export function verifySeoAuditRepair(c,options={}){
  const daily=codingCompletionHistoricalView();
  if(!daily)return verifySeoAuditRepairOriginal(c,options);
  assert.equal((options.rawHead===undefined?daily.rawHead:options.rawHead),daily.rawHead,'Daily source drift: actual raw SEO head required');
  return verifySeoAuditRepairOriginal(c,{rawHead:daily.head,
   read:options.read===undefined?daily.blob:typeof options.read==='function'?daily.projectRead(options.read):options.read,
   readContent:options.readContent===undefined?daily.content:typeof options.readContent==='function'?daily.projectContent(options.readContent):options.readContent,
   readDiff:options.readDiff===undefined?daily.diff:typeof options.readDiff==='function'?daily.projectDiff(options.readDiff):options.readDiff,
   isAncestor:options.isAncestor===undefined?daily.ancestor:typeof options.isAncestor==='function'?daily.projectAncestor(options.isAncestor):options.isAncestor},daily);
 }
 export function seoAuditHistoricalView(reader=null){
  const daily=codingCompletionHistoricalView(reader);
  if(!daily)return seoAuditHistoricalViewOriginal(reader);
  const inner=seoAuditHistoricalViewOriginal(reader===null?null:daily.read,daily),ref=r=>r===daily.rawHead?'HEAD':r;
  const readProject=source=>{const fn=inner.projectRead(daily.projectRead(source));return(r,p)=>fn(ref(r),p)};
  const contentProject=source=>{const fn=inner.projectContent(daily.projectContent(source));return(r,p)=>fn(ref(r),p)};
  const diffProject=source=>{const fn=inner.projectDiff(daily.projectDiff(source));return(a,b)=>fn(ref(a),ref(b))};
  const ancestorProject=source=>{const fn=inner.projectAncestor(daily.projectAncestor(source));return(a,b)=>fn(ref(a),ref(b))};
  const view={...inner,rawHead:daily.rawHead,affected:p=>daily.affected(p)||inner.affected(p),assertCurrent:daily.assertCurrent,
   currentContent:daily.currentContent,nativeAuthentic:daily.nativeAuthentic,nativeContentAuthentic:daily.nativeContentAuthentic,
   read:(r,p)=>inner.read(ref(r),p),blob:(r,p)=>inner.blob(ref(r),p),content:(r,p)=>inner.content(ref(r),p),
   diff:(a,b)=>inner.diff(ref(a),ref(b)),ancestor:(a,b)=>inner.ancestor(ref(a),ref(b)),
   projectRead:readProject,projectContent:contentProject,projectDiff:diffProject,projectAncestor:ancestorProject};
  daily.assertCurrent();return Object.freeze(view);
 }
 export function seoAuditOriginalSource(path,bytes){
  const daily=codingCompletionHistoricalView();
  if(!daily)return seoAuditOriginalSourceOriginal(path,bytes);
  return seoAuditOriginalSourceOriginal(path,codingCompletionOriginalSource(path,bytes,daily),daily);
 }
 """
 # One additive suffix; every original assertion remains recoverable byte-for-byte.
 old="\nexport function seoAuditOriginalSource(path,bytes){" # the original declaration was renamed above
 assert old not in sources[seo]
 inverses[seo].append(['',wrappers]);sources[seo]+=wrappers
 assert sources[seo].count(seo_policy_token)==1
 sources[seo]=sources[seo].replace(seo_policy_token,seo_policy_line,1)

for p in sources:
 restored=sources[p]
 for before,after in reversed(inverses[p]):
  assert after and restored.count(after)==1,(p,'inverse mismatch')
  restored=restored.replace(after,before)
 assert restored==original[p],(p,'whole original source not restored')

native_donors=[{'source':donor,'base':original_base,'paths':daily_paths,'exactPaths':[p for p in daily_paths if p!='wrangler.jsonc']}]
for p,pairs in inverses.items():
 if p in sources:continue
 restored=files[p]
 for old,added in reversed(pairs):
  assert added and restored.count(added)==1,(p,'exact runtime inverse required')
  restored=restored.replace(added,old)
 assert restored==text(base,p),(p,'whole actual Core/runtime source must restore')
record={
 'proof':'EXACT_CODING_COMPLETION_RUNTIME_20261016','base':base,'payload':payload,'paths':paths,'maintenancePaths':maintenance,'sourceBaseProductionAccepted':False,'sourceBaseOriginalSourceQualified':False,'originalBaseSourceQualification':'PENDING_ACTUAL_MAIN_PRODUCTION_ACCEPTANCE','qualificationContext':'private_native_source_chain_only','actualMainAccepted':False,'actualServingVerified':False,'actualDeploymentPerformed':False,'nativeDonors':native_donors,
 'authority':{'instruction':'Deploy all nine coding packages','approvalLabel':'Matt,16October2026,18:17BST;existing scoped approvals retained','scope':'Approved six-path private daily drafting engine only; unrelated Stress/Fit/G2 preparation remains retained and untouched','publicationApproved':False,'publicationApprovalScope':'No new daily or article public-copy publication approval; exact existing donor runtime and UI approvals retained','clinicalActivationApproved':False,'newSpendApproved':False},
 'features':{
  'daily':{'donor':donor,'paths':daily_paths,'exactDonorBlobs':{p:blob(donor,p) for p in daily_paths},'exactCurrentDonorPaths':[p for p in daily_paths if p!='wrangler.jsonc'],'currentConfigurationRetarget':daily_configuration['proof'],'priorPrivateProof':'622f96c148c3b82a6e8afd098bb817230df48a89','priorPrivateProofBaseIsProductionAccepted':False,'privateOnly':True},
 },
 'controls':{'creationAttemptsPerLondonDay':1,'modelCallsPerAttempt':2,'retryCalls':0,'gateway':'shift-ai','sharedRollingDayDollars':2,'rateLimitPerMinute':10,'loggingExportEnabled':False,'publicWrites':False,'publicWritesControlScope':'Private daily drafting engine only','memberDataReads':False,'newCron':False,'newQueue':False,'originalKnowledgeIngestionPreserved':True,'exactPublicCopyApprovalRequired':True,'applicableQualifiedReviewRequired':True,'freshGatewayProofBeforeActivationRequired':True,'originalSourceLimitsRaised':False,'originalAssertionsRemoved':0,'predictiveModelActivated':False,'gpContractChanged':False,'factualWeekContractChanged':False},
 'releaseConfiguration':{'authorisedExistingVars':{'DAILY_WEBSITE_CONTENT_ENABLED':'true','DAILY_CONTENT_GATEWAY':'shift-ai','DAILY_CONTENT_BUDGET_VERIFIED':'true'},'onlyExactThreeVarDelta':True,'wholeFileInverseToActualBaseRequired':True,'allOtherBindingsAndConfigurationUnchanged':True,'acceptedCsvGuardQueryAndFinalAssertionRetained':True,'acceptedWAllowsZeroAdditionalCsvEdit':csv_uses_admitted_week,'currentConfigurationWholeInverseRequired':True,'protectedConfigurationSha256':hashlib.sha256(wrangler_before.encode()).hexdigest(),'configuredSourceSha256':hashlib.sha256(wrangler_after.encode()).hexdigest(),'freshActualGatewayBudgetAuthLoggingRetriesProofBeforeActivation':True},
 'sourceMaintenance':{'selectedTop':selected_top,'originalWAndGpSeoModuleUnchanged':use_gp_top,'originalWComparisonTestUnchanged':csv_uses_admitted_week,'topSourceTransformerSha256':top_transformer_sha if use_gp_top else None,'originalDailySixDonorBlobsReceiptPreserved':True,'exactFiveOtherDailyPayloadBlobsPreserved':True,'dailyConfigurationTransformerSha256':daily_config_transformer_sha,'currentConfigurationChangedOnlyByExactThreeApprovedVars':True,'eofNormalisation':'One donor-only final newline removed only in maintenance','singleOuterSourceFrame':True,'aggregateHistoricalFacts':'Existing immutable kernel only; no new per-view aggregate fact map','nativeObjectsDissociated':True,'nativeAlternatesAbsent':True,'recoveredNativeFixtureTreesPreserved':native_fixture_trees,'originalKernelFallbackAndContextGuardsUnchanged':True,'noSuppliedCallbackVerdictOrViewCache':True,'arbitraryReferenceAndDirectoryNativeFallbackRetained':True,'allExistingSourceAndPriorLedgerRecordsRetained':True,'productionSourceCommandsUnchanged':True,'sourceBaseIsNotProductionAcceptance':True}
}
policy={'base':base,'payload':payload,'paths':paths,'maintenancePaths':maintenance,'payloadBlobs':payload_blobs,'record':record,'inverses':inverses,'donors':native_donors}
imports="import assert from 'node:assert/strict';\nimport {makeFreshCleanHint} from './fresh-food-source-clean-20261015.mjs';\nimport {makeFreshCleanHeadHint,freshDetachedSourceHead} from './fresh-food-source-head-20261016.mjs';\nimport {immutableHistoryExecFileSync as execFileSync,withImmutableHistoryVerification,immutableHistorySourceHead,assertGitTrackedSourceVisible} from './immutable-git-facts.mjs';\n"
imports+="import {readSeoNativeImmutableFacts} from './seo-native-immutable-facts-20261016.mjs';\n"
sources[scope]=imports+'const policy='+json.dumps(policy,separators=(',',':'),ensure_ascii=True)+';\n'+(templates/'scope-body.mjs').read_text()
sources[test]=(templates/'coding-scope.test.mjs').read_text()
assert set(sources)==set(maintenance)
for p,s in sources.items():write(p,s)
git('add','--',*maintenance)
assert set(git('diff','--cached','--name-only',payload).decode().splitlines())==set(maintenance)
git('diff','--check','--cached')
maintenance_tree=git('write-tree').decode().strip()
maintenance_source=commit(maintenance_tree,payload,'Bind one coding-completion source frame with whole prior source restoration and original test entry; not production acceptance')
git('checkout','--detach','--force',maintenance_source)
previous=json.loads(text(base,ledger));current=json.loads(json.dumps(previous));assert key not in current
current[key]={**record,'maintenanceSource':maintenance_source}
write(ledger,json.dumps(current,indent=2,ensure_ascii=False)+'\n')
git('add','--',ledger)
assert git('diff','--cached','--name-only',maintenance_source).decode().strip()==ledger
final_tree=git('write-tree').decode().strip()
final=commit(final_tree,maintenance_source,'Register exact coding-completion source preparation; required production and live acceptance remain pending')
git('checkout','--detach','--force',final)
assert git('status','--porcelain').strip()==b''
assert_independent_object_store()
git('merge-base','--is-ancestor',args.previous_private,final)
git('diff','--check',base,final)
assert set(git('diff','--name-only',base,final).decode().splitlines())==set(paths+maintenance+[ledger])
removed=current.copy();del removed[key];assert removed==previous
packet=root.parent/(root.name+'-evidence');packet.mkdir(exist_ok=True)
receipt={'root':str(root),'base':base,'baseTree':git('rev-parse',base+'^{tree}').decode().strip(),'sourceBaseProductionAccepted':False,'sourceBaseOriginalSourceQualified':False,'originalBaseSourceQualification':'PENDING_ACTUAL_MAIN_PRODUCTION_ACCEPTANCE','qualificationContext':'private_native_source_chain_only','actualMainAccepted':False,'actualServingVerified':False,'actualDeploymentPerformed':False,'dailyDonor':donor,'payload':payload,'payloadTree':payload_tree,'maintenanceSource':maintenance_source,'maintenanceTree':maintenance_tree,'head':final,'tree':final_tree,'paths':paths,'maintenancePaths':maintenance,'payloadBlobs':payload_blobs,'wholePriorSourcesRestoreExactly':True,'allPriorLedgerRecordsUnchanged':True,'donorWhitespaceNormalisedOnlyInMaintenance':True,'productionWorkflowUnchanged':blob(base,'.github/workflows/cloudflare-production-promote.yml')==blob(final,'.github/workflows/cloudflare-production-promote.yml'),'privateNativeGraphCreated':True,'nativeObjectsDissociated':True,'nativeAlternatesAbsent':True,'aggregatePerViewFactMap':False,'remoteRefsChanged':False,'deployed':False,'activated':False,'modelCalls':0,'paidCalls':0,'tests':'pending actual changed-source tests','builder':str(Path(__file__))}
(packet/'native-graph-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
git('bundle','create',str(packet/'coding-completion-private-source.bundle'),'HEAD','^'+base)
(packet/'exact-source.patch').write_bytes(git('diff','--binary',base,final))
print(json.dumps(receipt,indent=2))
