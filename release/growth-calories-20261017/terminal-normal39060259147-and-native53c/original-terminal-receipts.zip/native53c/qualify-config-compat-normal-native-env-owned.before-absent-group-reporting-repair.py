from pathlib import Path
import subprocess,os,time,signal,json,hashlib,re,datetime,collections,sys
R=Path('/Users/shiftsometimberltd/SST/organic-deploy-20261017')
root=R/'daily-only-core526-v12-config-compat-private'
packet=R/'daily-only-core526-v12-config-compat-private-evidence'/'normal-native-environment'
donor=R/'daily-only-core526-v10-private'
previous_root=R/'daily-only-core526-v11-error-contract-private'
head='53c071f6356d2a7b120049d034ab32e49fc3a904'
tree='769f8e1c881416e26079acc30d5e4dc644b54386'
previous='29ba9a8402ac1343096b030be945a56fffdbfb53'
mode=sys.argv[1] if len(sys.argv)==2 else ''
assert mode in ['original370','native'],'Explicit original qualification stage required'
cap=1200
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
allowed=['HOME','USER','LOGNAME','SHELL','TMPDIR','LANG','LC_ALL','LC_CTYPE','TZ','TERM']
child_env={k:os.environ[k] for k in allowed if k in os.environ}
child_env.update({'PATH':'/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'})
assert not any(k.startswith('GIT_') for k in child_env),'Original Node hint tests require no injected Git environment controls'
controller_git_env={**child_env,'GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0','GIT_ASKPASS':'/usr/bin/false','GCM_INTERACTIVE':'Never'}
assert not any(re.search(r'TOKEN|SECRET|PASSWORD|CLOUDFLARE|OPENAI|ANTHROPIC|STRIPE|GATEWAY|API_KEY|WRANGLER',k,re.I) for k in child_env),'No provider/model/auth variables allowed'
def g(directory,*a,allow_empty=False):
 result=subprocess.run(['/usr/bin/git','-C',str(directory),'--no-replace-objects',*a],capture_output=True,env=controller_git_env)
 if allow_empty and result.returncode==1 and a==('show-ref',):return ''
 result.check_returncode();return result.stdout.decode().strip()
tools=['package-lock.json','node_modules/esbuild/package.json','node_modules/esbuild/lib/main.js','node_modules/wrangler/package.json','node_modules/@esbuild/darwin-arm64/bin/esbuild']
pinned=json.loads((R/'daily-v10-source-before.json').read_text())['installedToolingSHA256']
assert set(pinned)==set(tools)
geometry_paths=['HEAD','index','config','packed-refs','FETCH_HEAD','objects/info/alternates','commondir','info/exclude']
def geometry(directory):
 return {p:digest(directory/'.git'/p) if (directory/'.git'/p).is_file() else None for p in geometry_paths}
def snap(directory,need_tools=True):
 untracked=g(directory,'ls-files','--others','--exclude-standard').splitlines()
 installed_link=(directory/'node_modules').is_symlink() and (directory/'node_modules').resolve()==(donor/'node_modules').resolve()
 unexpected=[p for p in untracked if not p.startswith('node_modules/') and not (p=='node_modules' and installed_link)]
 assert not unexpected,('Unexpected untracked source',str(directory),unexpected[:10])
 fingerprints={p:digest(directory/p) for p in tools if (directory/p).is_file()}
 if need_tools:assert fingerprints==pinned,('Exact original pinned tooling required',str(directory))
 return {'root':str(directory),'head':g(directory,'rev-parse','HEAD'),'tree':g(directory,'rev-parse','HEAD^{tree}'),'status':g(directory,'status','--porcelain=v1','--untracked-files=no'),'installedToolingSHA256':fingerprints,'untrackedSourceOutsideInstalledTooling':unexpected,'geometry':geometry(directory),'refs':g(directory,'show-ref',allow_empty=True),'nodeModulesResolved':str((directory/'node_modules').resolve()) if (directory/'node_modules').exists() else None}
def frame():
 return {'source':snap(root),'original07b8Donor':snap(donor),'previous29ba':snap(previous_root)}
def assert_fresh(before):
 for label,directory in [('source',root),('original07b8Donor',donor),('previous29ba',previous_root)]:
  prior=before[label]
  assert g(directory,'rev-parse','HEAD')==prior['head'],('Real source HEAD moved',label)
  assert geometry(directory)==prior['geometry'],('Real Git geometry changed',label)
  for args in [('diff','--quiet','HEAD','--'),('diff','--quiet','--cached','--')]:
   result=subprocess.run(['/usr/bin/git','-C',str(directory),'--no-replace-objects',*args],env=child_env,capture_output=True)
   assert result.returncode==0,('Real tracked source changed',label)
def heavy_processes():
 rows=subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,pgid=,command='],env=child_env,text=True).splitlines()
 found=[]
 for row in rows:
  fields=row.strip().split(None,3)
  if len(fields)!=4:continue
  pid,ppid,pgid,command=fields
  if int(pid)==os.getpid() or int(ppid)==os.getpid():continue
  # Inspect only actual executable process classes, never print complete args.
  executable=command.split(None,1)[0]
  if ('node' in Path(executable).name and any(k in command for k in ['--test','full-page-proof.mjs','compiled-worker-proof','verify-shift-ai-original'])):
   try:
    cwd=subprocess.check_output(['/usr/sbin/lsof','-a','-p',pid,'-d','cwd','-Fn'],env=child_env,text=True,timeout=4)
    paths=[x[1:] for x in cwd.splitlines() if x.startswith('n')]
   except Exception as error:raise AssertionError(('Cannot establish active test ownership',pid,type(error).__name__))
   if any('/SST/' in p for p in paths):found.append({'pid':int(pid),'ppid':int(ppid),'pgid':int(pgid),'class':'activeSSTNativeOrBrowserTest','cwd':paths})
  if any(k in command for k in ['qualify-daily-v10-native.py','qualify-config-compat','qualify-original-ai-81bd','qualify-error-contract-diagnostics']) and 'python' in Path(executable).name:
   found.append({'pid':int(pid),'ppid':int(ppid),'pgid':int(pgid),'class':'activeQualificationController'})
 return found
core=Path('/Users/shiftsometimberltd/SST/gp-current-acceptance-20261016-4a7e693a/accepted-utility-main-20261017')
finite=json.loads((core/'growth-adoption-526-detached-original-qualification-finite10-result.json').read_text())
assert finite['status']=='PASS' and finite['source']=='526b0b2e47bb768d910ba329a3f10bd110199412' and all(finite['checks'].values())
assert finite['cleanup']['ownedProcessGroupEmpty']
core_native=json.loads((core/'growth-adoption-526-detached-original-qualification-native510-result.json').read_text())
assert core_native['status']=='PASS' and core_native['source']=='526b0b2e47bb768d910ba329a3f10bd110199412' and all(core_native['checks'].values())
baseline_log=core/'growth-adoption-526-detached-original-qualification-native510.tap'
assert digest(baseline_log)==core_native['logSHA256']
names=lambda s:collections.Counter(re.findall(r'^# Subtest: (.+)$',s,re.M))
original510=names(baseline_log.read_text());assert sum(original510.values())==510
focused_log=R/'daily-v10-focused.tap'
focused_result=json.loads((R/'daily-v10-focused-result.json').read_text());assert focused_result['passed']
focused_names=set(names(focused_log.read_text()))
csv_names=set(re.findall(r"^test\('([^']+)'",(root/'member-experience/tests/weight-import-mapping-ui.test.mjs').read_text(),re.M))
assert len(focused_names)==40 and len(csv_names)==4
original36=focused_names-csv_names;assert len(original36)==36
added='recorded-week protected configuration compatibility rejects every nondeclared delta and forged admission'
assert not (set(original510)&original36) and added not in original510 and added not in original36
required=original510.copy();required.update(original36);required.update([added]);assert sum(required.values())==547
before=frame()
assert before['source']['head']==head and before['source']['tree']==tree and not before['source']['status']
assert before['previous29ba']['head']==previous and not before['previous29ba']['status']
assert before['original07b8Donor']['head']=='07b8d194d21e5727610828a9c28220edb2cc72b1' and not before['original07b8Donor']['status']
assert not (root/'.git/objects/info/alternates').exists() and not (root/'.git/commondir').exists()
active=heavy_processes();assert not active,('Another actual SST test/controller is active; do not duplicate',active)
if mode=='native':
 missing_case=json.loads((packet/'original370-complete-result.json').read_text())
 assert missing_case['passed'] and missing_case['head']==head
 assert before==missing_case['after'],'Preserve exact original370 source/donor/tooling frame'
assert_fresh(before)
claim=packet/(mode+'-qualification-claim.json')
with claim.open('x') as out:json.dump({'atUtc':now(),'controller':os.getpid(),'source':head,'tree':tree,'mode':mode,'capSeconds':cap,'cpuSlot':'Actual Core finite10 PASS/cleanup andAI81bd stage completed; no other actual SST test/controller','reason':'Original Node environment restored: no injectedGIT_ variables; noninteractiveGit controls remain controller-only and every provider/model/auth variable stays excluded. Original370 reruns under this normal native context, then unchanged547. Previous injected-environment attempt is retained as invalid qualification, not a timeout or release-code verdict. Changed source repairs all3demonstrated prior failures: exact source-drift error contract plus authenticated literal three-line Daily configuration compatibility. Original commands/caps/native names remain required; no unrelated retry.'},out,indent=2)
(packet/(mode+'-source-before.json')).write_text(json.dumps(before,indent=2)+'\n')
if mode=='original370':
 stages=[('original370',['/usr/local/bin/node','--test','--test-reporter=tap','--test-name-pattern=^actual custom readers retain fresh literal HEAD calls after successful default admission$','tests/release-machinery-repair-composition.test.mjs'],'actual custom readers retain fresh literal HEAD calls after successful default admission')]
else:stages=[('native',['/usr/local/bin/node','--test','--test-reporter=tap','tests/food-diary-london-date-stack-20261015.test.mjs','tests/seo-audit-scope-20261016.test.mjs'],None)]
def group_members(pgid):
 result=subprocess.run(['/bin/ps','-axo','pid=,pgid=,uid=,ppid=,comm='],capture_output=True,text=True,env=child_env)
 result.check_returncode()
 return [line.strip() for line in result.stdout.splitlines() if len(line.split())>=4 and line.split()[1]==str(pgid)]
results=[]
for label,command,target_name in stages:
 assert_fresh(before);start=time.monotonic();started=now();timeout=False;signals=[];guard_error=None
 log=packet/(label+'.tap')
 with log.open('x') as out:
  proc=subprocess.Popen(command,cwd=root,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,env=child_env)
  running={'atUtc':started,'stage':label,'controller':os.getpid(),'pid':proc.pid,'pgid':proc.pid,'head':head,'tree':tree,'capSeconds':cap,'command':command,'childEnvironmentKeys':sorted(child_env),'providerModelAuthEnvironmentStripped':True}
  (packet/'qualification-running.json').write_text(json.dumps(running,indent=2)+'\n')
  print(json.dumps({'stage':label,'pid':proc.pid,'controller':os.getpid(),'head':head,'capSeconds':cap,'startedAt':started}),flush=True)
  next_guard=time.monotonic()+10
  while proc.poll() is None:
   if time.monotonic()-start>=cap:
    timeout=True;break
   if time.monotonic()>=next_guard:
    try:assert_fresh(before)
    except Exception as error:guard_error=repr(error);break
    next_guard=time.monotonic()+10
   time.sleep(.25)
  if proc.poll() is None:
   os.killpg(proc.pid,signal.SIGTERM);signals.append('TERM')
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);signals.append('KILL');proc.wait(timeout=5)
  code=proc.wait()
 members=group_members(proc.pid)
 if members:
  assert all(int(row.split()[2])==os.getuid() for row in members),'Ambiguous/foreign process group: retain and stop'
  os.killpg(proc.pid,signal.SIGTERM);signals.append('TERM-descendants');time.sleep(.3)
  members=group_members(proc.pid)
  if members:
   assert all(int(row.split()[2])==os.getuid() for row in members),'Ambiguous/foreign process group: retain and stop'
   os.killpg(proc.pid,signal.SIGKILL);signals.append('KILL-descendants');time.sleep(.2)
 members=group_members(proc.pid);empty=not members
 seconds=time.monotonic()-start;raw=log.read_text();counts={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',raw,re.M)}
 after_error=None
 try:after=frame()
 except Exception as error:after=None;after_error=repr(error)
 actual_names=names(raw);baseline_same=digest(baseline_log)==core_native['logSHA256']
 selected_pass=bool(target_name and re.search(r'^ok \d+ - '+re.escape(target_name)+r'(?:\s|$)',raw,re.M))
 named_proof=(actual_names==required) if label=='native' else selected_pass
 full_counts=(counts.get('tests')==547 and counts.get('pass')==547 and all(counts.get(k)==0 for k in ['fail','cancelled','skipped','todo'])) if label=='native' else (counts.get('pass',0)>=1 and counts.get('fail',0)==0 and counts.get('cancelled',0)==0)
 passed=code==0 and not timeout and guard_error is None and after==before and empty and named_proof and full_counts and baseline_same
 result={'atUtc':now(),'startedAt':started,'stage':label,'head':head,'tree':tree,'command':command,'capSeconds':cap,'seconds':seconds,'exit':code,'timedOut':timeout,'counts':counts,'sourceDonorToolingGeometryUnchanged':after==before,'afterError':after_error,'inRunSourceGuardError':guard_error,'ownedGroupEmpty':empty,'ownedGroupMembers':members,'signals':signals,'targetName':target_name,'targetOriginalCasePassed':selected_pass if target_name else None,'all547NamesExactlyPreserved':actual_names==required if label=='native' else None,'requiredNameCount':sum(required.values()) if label=='native' else 1,'actualNamedCaseCount':sum(actual_names.values()),'missingRequiredNames':list((required-actual_names).elements()) if label=='native' else [],'unexpectedNames':list((actual_names-required).elements()) if label=='native' else [],'baselineCoreNativeSHA256':core_native['logSHA256'],'baselineCoreNativeUnchanged':baseline_same,'logSHA256':digest(log),'childEnvironmentKeys':sorted(child_env),'providerModelAuthEnvironmentStripped':True,'passed':passed,'fullQualification':label=='native','deployed':False,'modelCalls':0}
 (packet/(label+'-result.json')).write_text(json.dumps(result,indent=2)+'\n')
 (packet/(label+'-source-after.json')).write_text(json.dumps(after,indent=2)+'\n')
 print(json.dumps(result),flush=True);results.append(result)
 if not passed:raise SystemExit('STOP: required diagnostic/original qualification failed; retain raw evidence; no unchanged automatic retry')
summary={'atUtc':now(),'head':head,'tree':tree,'mode':mode,'passed':all(x['passed'] for x in results),'results':[{'stage':x['stage'],'logSHA256':x['logSHA256'],'seconds':x['seconds'],'passed':x['passed']} for x in results],'after':frame(),'fullQualification':mode=='native','deployed':False,'modelCalls':0}
(packet/(mode+'-complete-result.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'complete':mode,'passed':summary['passed'],'head':head,'fullQualification':mode=='native'}),flush=True)
